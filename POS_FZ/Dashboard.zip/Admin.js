document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('item-form');
    const tableBody = document.getElementById('items-table-body');
    let currentItemId = null;

    form.addEventListener('submit', async (event) => {
        event.preventDefault();

        const formData = new FormData(form);
        try {
            const method = currentItemId ? 'PUT' : 'POST';
            const url = currentItemId ? `/api/items/${currentItemId}` : '/api/items';
            const response = await fetch(url, {
                method: method,
                body: formData
            });

            if (response.ok) {
                await loadItems();
                form.reset();
                currentItemId = null; // Reset currentItemId after successful submission
            } else {
                alert('Error saving item');
            }
        } catch (error) {
            console.error('Error:', error);
            alert('An unexpected error occurred. Please try again later.');
        }
    });

    async function loadItems() {
        try {
            const response = await fetch('/api/items');
            if (!response.ok) throw new Error('Failed to load items.');
            const items = await response.json();
            tableBody.innerHTML = '';

            items.forEach(item => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${item.name}</td>
                    <td>${item.price}</td>
                    <td><img src="${item.image}" alt="${item.name}" width="100"></td>
                    <td>
                        <button onclick="editItem(${item.id})">Edit</button>
                        <button onclick="deleteItem(${item.id})">Delete</button>
                    </td>
                `;
                tableBody.appendChild(row);
            });
        } catch (error) {
            console.error('Error:', error);
            alert('An error occurred while loading items. Please try again later.');
        }
    }

    window.editItem = async (id) => {
        try {
            const response = await fetch(`/api/items/${id}`);
            if (!response.ok) throw new Error('Failed to fetch item.');
            const item = await response.json();
            document.getElementById('item-name').value = item.name;
            document.getElementById('item-price').value = item.price;
            document.getElementById('item-image').value = ''; // Clear file input for editing
            currentItemId = id;
        } catch (error) {
            console.error('Error:', error);
            alert('An error occurred while fetching item details.');
        }
    };

    window.deleteItem = async (id) => {
        try {
            const response = await fetch(`/api/items/${id}`, {
                method: 'DELETE'
            });

            if (response.ok) {
                await loadItems();
            } else {
                alert('Error deleting item. Please try again.');
            }
        } catch (error) {
            console.error('Error:', error);
            alert('An unexpected error occurred. Please try again later.');
        }
    };

    loadItems(); // Load items on page load
});
